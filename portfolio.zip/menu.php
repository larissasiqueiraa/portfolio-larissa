<div class="container">
    <div class="row">
    
        <div class="col-md-6">
            <h3 class="hide-mobile">LS</h3>
        </div>
        <div class="col-md-6">
            <nav class="menu">
                <ul>
                    <li ><a href="index.php" class="cor-hover">Início</a></li>
                    <li ><a href="sobre.php" class="cor-hover">Sobre</a></li>
                    <li ><a href="habilidades.php" class="cor-hover">Habilidades</a></li>
                    <li ><a href="projetos.php" class="cor-hover">Projetos</a></li>
                    <li ><a href="contato.php" class="cor-hover">Contato</a></li>
                </ul>
            </nav>
        </div>
    </div>
</div>