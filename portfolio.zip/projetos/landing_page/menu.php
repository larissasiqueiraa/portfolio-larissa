<div class="img-fundo">
    
</div>

<div class="container text-center">
    <div class="logo-container">
        <span class="letterc"><i class="fa-solid fa-c"></i></span>
    </div>

    <h1>A history of everything you copy</h1>
    <p>Clipboard allows you to track and organize everything you copy. Instantly</p>
    <p class="quebra">access your clipboard on all your devices.</p>

    <div class="principal">
        <div class="btn1"><a href="">Download for iOS</a></div>
        <div class="btn2"><a href="">Download for MAC</a></div>
    </div>
</div>