<footer class="rodape">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="logo-rodape">
                    <span class="letterc2"><i class="fa-solid fa-c"></i></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="infos-rodape">
                    <div class="row">
                        <div class="col-4">
                            <p>FAQs</p>
                        </div>
                        <div class="col-4">
                            <p>Privacy Policy</p>
                        </div>
                        <div class="col-4">
                            <p>Install Guide</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p>Contact Us</p>
                        </div>
                        <div class="col-4">
                            <p>Press Kit</p>
                        </div>
                        <div class="col-4"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="sociais">
                    <i class="fa-brands fa-square-facebook"></i>
                    <i class="fa-brands fa-instagram"></i>
                    <i class="fa-brands fa-x-twitter"></i>
                </div>
            </div>
        </div>
    </div>
</footer>